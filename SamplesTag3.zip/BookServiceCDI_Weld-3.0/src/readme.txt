Analog zum Beispiel aus Buch "Beginning JEE 7".
Benutzt Weld-3.0.0, d.h. andere Startsequenz.