package sk.train;

public interface NumberGenerator {

	public String generateNumber();
}
