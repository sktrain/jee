package sk.train.jdbc;

import java.sql.*;
import java.io.*;

public class JdbcTest_Derby {

	public static void main(String[] args) {

		Connection myconnect = null;

		DriverManager.setLogWriter(new PrintWriter(System.out));

		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");

			myconnect = DriverManager.getConnection("jdbc:derby://localhost:1527/seconddb");

			System.out.println(myconnect.getMetaData().getDatabaseProductName());

//			Statement st = myconnect.createStatement();
//			String query = "SELECT * from employees";
//			ResultSet rs = st.executeQuery(query);
//			ResultSetMetaData rsmeta = rs.getMetaData();
//			System.out.println(rsmeta.getColumnName(1)+ " : " +
//					rsmeta.getColumnName(2)+ " : " +rsmeta.getColumnName(3));
//			while (rs.next()){
//				System.out.println(rs.getString(1) + " | " + rs.getString(2)+
//						" | "+rs.getString(3));
//			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (myconnect != null) {
				try {
					myconnect.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

}