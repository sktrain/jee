package sk.train.jdbc;

import java.sql.*;

public class JdbcTest_H2 {

	public static void main(String[] args) {

		// DriverManager.setLogWriter(new PrintWriter(System.out));

		try {
			Class.forName("org.h2.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try (Connection myconnect = DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test", "sa", "")) {

			System.out.println(myconnect.getMetaData().getDatabaseProductName());

			Statement st = myconnect.createStatement();
			String query = "SELECT * from hr.employees";
			ResultSet rs = st.executeQuery(query);
			ResultSetMetaData rsmeta = rs.getMetaData();
			System.out.println(
					rsmeta.getColumnName(1) + " : " + rsmeta.getColumnName(2) + " : " + rsmeta.getColumnName(3));
			while (rs.next()) {
				System.out.println(rs.getString(1) + " | " + rs.getString(2) + " | " + rs.getString(3));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}