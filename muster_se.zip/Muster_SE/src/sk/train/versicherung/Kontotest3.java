/* Kontotest2-Klasse f�r die Verwendung von Konto2 
 * mit Exception-Handling (f�ngt alle unsere Exceptions )
 */

package sk.train.versicherung;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.util.Calendar;

public class Kontotest3 {
	
	public static void main(String[] args) {
		/* Verwaltung von 10 Konten per array */
		Konto2[] kontenfeld = new Konto2[10];
				
		/* F�llen des Arrays mit Beispielskonten */
		for (int i = 0; i<kontenfeld.length; ++i){
			//Erzeugung der Geburtsdaten
			Calendar gebdat = Calendar.getInstance();
			gebdat.set(1960+i, Calendar.JANUARY+i, i+1);
			try {
				kontenfeld[i] = new Konto2( (int)(Math.random()*1000), //Cast bindet st�rker als *
											"Mustermann"+i,
											gebdat,
											new BigDecimal((Math.random()*20000.0)));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		/* testweise Ausgabe des Feldes mit Formatierung */
		for (int i = 0; i<kontenfeld.length; ++i){
			//f�r formatierte Ausgabe des Geburtsdatums
			Calendar gebdatum = kontenfeld[i].getGeburtsdatum();
			String gbd = gebdatum.get(Calendar.DATE) + "." + (gebdatum.get(Calendar.MONTH)+1)
							+ "." + gebdatum.get(Calendar.YEAR); //gbd enth�lt spezifisch formatierten String
			//alternative Formatierung via DateFormat-Klasse
			DateFormat df = DateFormat.getDateInstance();
			String gbd1 = df.format(gebdatum.getTime());  //gbd1 enth�lt nach aktuellen lokalen Einstellungen formatiertes Datum
			//alternative Formatierung via format-Methode der Klasse String (nicht Locale aware)
			String gbd2 = String.format("%td.%tm.%ty", gebdatum, gebdatum, gebdatum); //gbd2 enth�lt formatiertes Datum
			System.out.println(kontenfeld[i] + ": " 
							   + gbd	//kann jeweils gegen gbd1 oder gbd2 ersetzt werden 
							   + ": " + kontenfeld[i].getAlter()
							   //Formatierung des BigDecimal mit 2 Nachkommastellen und Rundung via format-Methode der Klasse String
					           + ": " + String.format("%.2f", kontenfeld[i].getMonatsrente())
					           //Formatierung des BigDecimal mit Euro-Zeichen via DecimalFormat-Klasse (Locale aware)
					           + ": " + new DecimalFormat( ",##0.00\u00A4" ).format(kontenfeld[i].getJahresrente()));
		}		
		
	}

}
