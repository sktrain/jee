package sk.train;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;

/**
 * Session Bean implementation class HelloEJB
 */
@Stateless
public class HelloEJB implements HelloEJBRemote {
	
		// Injizierung der Datasource
		// Voraussetzung: Datasource ist in Wildfly eingerichtet mit dem verwendeten
		// JNDI-Namen
		// Hier ist wichtig!!!: Statt Attribut "name" muss Attribut "lookup" verwendet
		// werden
		// @Resource(lookup="java:/jdbc/OracleDS") //bis Wildfly 10

		@Resource(lookup = "java:/H2DS") // ab Wildfly11
		private DataSource ds;

		// so geht es f�r die DefaultDS, dia auf H2 basiert
		// @Resource(name="ExampleDS")
		// private DataSource ds;

    /**
     * Default constructor. 
     */
    public HelloEJB() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String getDataSource() throws SQLException {
		// TODO Auto-generated method stub
		return ds.getConnection().getMetaData().getDatabaseProductName();
	}

}
