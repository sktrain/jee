package sk.train;

import java.sql.SQLException;

import javax.ejb.Remote;

@Remote
public interface HelloEJBRemote {
	
	String getDataSource() throws SQLException;
	

}
