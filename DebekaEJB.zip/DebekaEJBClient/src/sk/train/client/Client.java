package sk.train.client;

import java.sql.SQLException;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import sk.train.HelloEJBRemote;


public class Client {

	public static void main(String[] args) throws NamingException, SQLException {
		// NamensContext beschaffen, setzt entsprechende Properties voraus
		final Hashtable<String, String> jndiProperties = new Hashtable<String, String>();
		jndiProperties.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
		final Context context = new InitialContext(jndiProperties);
		// final Context context = new InitialContext();

		System.out.println("Bis hier ok");		

		// Client-seitigen Proxy beschaffen
		//context.lookup("java:global/EJB_Hello_H2_DS/Hello_DS_Bean!sk.train.Hello_DS_BeanRemote");
		HelloEJBRemote stub = (HelloEJBRemote) 
				context.lookup("ejb:/DebekaEJB/HelloEJB!sk.train.HelloEJBRemote");
		
		//Service aufrufen via Stub
		System.out.println(stub.getDataSource());
}
}
