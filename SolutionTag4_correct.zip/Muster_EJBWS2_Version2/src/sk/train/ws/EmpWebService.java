package sk.train.ws;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.EJB;
import javax.jws.WebService;

import sk.train.model.Department;
import sk.train.model.Employee;
import sk.train.service.EmpServiceLocal;

@WebService(endpointInterface = "sk.train.ws.EmpServiceIf")
public class EmpWebService implements EmpServiceIf {
	
	@EJB
	private EmpServiceLocal myejb; 

	@Override
	public void saveEmp(Employee emp) {
		myejb.saveEmp(emp);
		
	}

	@Override
	public Employee readEmp(long id) {
		return myejb.readEmp(id);
	}

	@Override
	public void removeEmp(long id) {
		myejb.removeEmp(id);
		
	}

	@Override
	public void setSalaryEmp(long id, BigDecimal sal) {
		myejb.setSalaryEmp(id, sal);
		
	}

	@Override
	public List<Employee> getEmpInDep(long departmentid) {
		return myejb.getEmpInDep(departmentid);
	}

	@Override
	public List<Employee> getAllEmps() {
		return myejb.getAllEmps();
	}

	@Override
	public List<Department> getAllDepartments() {
		return myejb.getAllDepartments();
	}

}
