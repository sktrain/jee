﻿/*============================================================================
  File:     Install_HR_DB_CreateUSER_DB_1

  Summary:  Creates the HR sample database -Step1:
		Create User HR und Create Database Kurs

  Date:     16.11.2013
  Updated:	
===========================================================================*/

-- ****************************************
-- Create User HR
-- ****************************************



CREATE ROLE "HR" LOGIN
  ENCRYPTED PASSWORD 'md570a4ec7bf82d831b09578f554141eed0'
  NOSUPERUSER INHERIT CREATEDB NOCREATEROLE NOREPLICATION;
COMMENT ON ROLE "HR" IS 'DB_user für Bsp-Schema HR';



-- ****************************************
-- Create Database
-- ****************************************


CREATE DATABASE "Kurs"
  WITH OWNER = "HR"
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'German_Germany.1252'
       LC_CTYPE = 'German_Germany.1252'
       CONNECTION LIMIT = -1;



