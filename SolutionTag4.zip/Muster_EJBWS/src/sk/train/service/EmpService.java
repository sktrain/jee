package sk.train.service;

import java.math.BigDecimal;
import java.util.List;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import sk.train.model.Department;
import sk.train.model.Employee;

/**
 * Session Bean implementation class EmpService
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.SUPPORTS)
public class EmpService implements EmpServiceLocal {

	@PersistenceContext
	private EntityManager em;

	// default-Konstruktor
	public EmpService() {
		super();
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void saveEmp(Employee emp) {		
		em.persist(emp);
	}

	@Override
	public Employee readEmp(long id) {
		Employee emp = em.find(Employee.class, id);
		return emp;
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void removeEmp(long id) {
		Employee emp = em.find(Employee.class, id);
		if (emp != null)
			em.remove(emp);
	}

	@Override
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void setSalaryEmp(long id, BigDecimal sal) {
		Employee emp = em.find(Employee.class, id);
		if (emp != null)
			emp.setSalary(sal);
	}
	
	@Override
	public List<Employee> getEmpInDep(long departmentid){
		Department d = em.find(Department.class, departmentid);
		if ( d != null ) return d.getEmployees();
		else throw new IllegalArgumentException( "keine g�ltige DepartmentID");
	}
	
	@Override
	public List<Employee> getAllEmps(){
		return em.createNamedQuery("Employee.findAll").getResultList();
	}
	
	@Override
	public List<Department> getAllDepartments(){
		return em.createNamedQuery("Department.findAll").getResultList();
	}
	
	
}
