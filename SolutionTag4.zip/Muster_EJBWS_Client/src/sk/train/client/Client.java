package sk.train.client;

import sk.train.ws.EmpServiceIf;
import sk.train.ws.EmpWebServiceService;
import sk.train.ws.Employee;

public class Client {

	public static void main(String[] args) {

		EmpWebServiceService serv = new EmpWebServiceService();
		
		EmpServiceIf stub = serv.getEmpWebServicePort();
		
		Employee king = stub.readEmp(100L);

	}

}
