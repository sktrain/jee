package org.agoncal.book.javaee7.chapter02.ex21;

/**
 * Created with IntelliJ IDEA.
 * User: i2118cl
 * Date: 10/04/13
 * Time: 16:27
 * To change this template use File | Settings | File Templates.
 */
public class Account {
}
