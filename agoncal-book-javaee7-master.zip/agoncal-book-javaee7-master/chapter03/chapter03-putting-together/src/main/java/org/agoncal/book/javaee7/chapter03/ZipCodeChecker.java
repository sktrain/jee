package org.agoncal.book.javaee7.chapter03;

/**
 * @author Antonio Goncalves
 *         APress Book - Beginning Java EE 7 with Glassfish 4
 *         http://www.apress.com/
 *         http://www.antoniogoncalves.org
 *         --
 */
@USA
public class ZipCodeChecker {

  public boolean isZipCodeValid(String zipCode) {
    // Call an external web service to check zipcode
    return true;
  }
}
